//         实现基本链表
// Created by 皮卡丘 on 2019/10/17.
//     任浩龙 2018141461344

#ifndef PIKA_LINK_HPP
#define PIKA_LINK_HPP
#include <iostream>
template <class type>
class link
{
public:
    bool       head;    //判断开头
    type       data;    //存储数据
    link<type>*next;    //存储地址
        link();         //构造函数
        link(type inpt);//带参构造
    type pop();         //出队当前
    type get();         //获取当前
    void add();         //插入节点
    void add(type inpt);//带参插入
    void del();         //删除当前
    void dlf();         //截断链表
    link<type> operator [] (int        inpt);
    void       operator =  (link<type> inpt);
};

/*-------------------------DEMO-------------------------
link<int>a;           //无初值创建
link<int>b(1);        //有初值创建
a=b;                  //重载等号
cout<<a.get()<<endl;  //获取内容
a.add(2);             //追加内容
cout<<a.next->data<<endl;
a.next->add(3);
cout<<a.next->next->data<<endl;
cout<<a[2].data;
-------------------------DEMO-------------------------*/

#endif //TEST1_LINK_HPP
