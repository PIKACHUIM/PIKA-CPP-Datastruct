//         实现基本链表
// Created by 皮卡丘 on 2019/10/17.
//     任浩龙 2018141461344

#include "link.hpp"
template <class type>
link<type>::link()
{
    head= true;
    next= nullptr;
}
template <class type>
link<type>::link(type inpt)
{
    link();
    this->data=inpt;
}
template <class type>
void link<type>::add()
{
    link<type>*temp=new link<type>;
    temp->head=false;
    temp->next=this->next;
    this->next=temp;
}
template <class type>
void link<type>::add(type inpt)
{
    link<type>*temp=new link<type>;
    temp->head=false;
    temp->data=inpt;
    temp->next=this->next;
    this->next=temp;
}
template <class type>
void link<type>::del()
{
    if(this->next== nullptr)return ;
    this->next=this->next->next;
}
template <class type>
type link<type>::pop()
{
    type temp=this->get();
    this->del();
    return temp;
}
template <class type>
type link<type>::get()
{
    return this->data;
}

template <class type>
void link<type>::dlf()
{
    this->next= nullptr;
}

template <class type>
link<type> link<type>::operator[](int inpu)
{
    link<type>*temp=new link<type>;
         temp->next=this->next;
         temp->data=this->data;
         temp->head=this->head;
    for(int loop=0;loop<inpu;loop++)
    {
        if(temp->next== nullptr)
            {
                std::cout<<"[ERRO]OUT INDEX OF THE LINK"<<std::endl;
                return *temp;
            }
        temp->head=temp->next->head;
        temp->data=temp->next->data;
        temp->next=temp->next->next;
    }
    return *temp;
}

template <class type>
void link<type>::operator =(link<type> inpu)
{
    this->data=inpu.data;
    this->next=inpu.next;
    this->head=inpu.head;
}